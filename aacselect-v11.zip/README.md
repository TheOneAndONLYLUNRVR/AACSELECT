# AACSELECT (unofficial fan project)
Upload EVERYTHING in this folder to the TOP LEVEL of your GitHub repo (server.js, package.json, wrangler.jsonc, render.yaml, public/).
RENDER (server + live data):  Root Directory = (empty) | Build = npm install | Start = node server.js | Health = /healthz | env DB_FILE=/data/data.json NODE_VERSION=22 | Disk at /data
CLOUDFLARE (optional front end): Root directory = (empty) | Build command = (empty) | Deploy = npx wrangler deploy
The page finds the server by itself (public/config.js). Test the server: open https://aacselect.onrender.com/healthz -> {"ok":1,...}
