# AACSELECT v14 (unofficial fan project) - exact settings
RENDER (runs the server):  Root Directory = EMPTY | Build Command = npm install | Start Command = node server.js  (NEVER npx wrangler deploy)
  Health Check Path = /healthz | Env: DB_FILE=/data/data.json, NODE_VERSION=22 | Disk mounted at /data | Auto-Deploy = On Commit
  Test: open https://YOUR-SERVICE.onrender.com/healthz  ->  {"ok":1,...}
CLOUDFLARE (shows the page):  Pages -> Upload assets -> upload aacselect-cloudflare-site.zip (no build). Add custom domain aacselect.com.
  Git build alternative: Root = / | Build command = EMPTY | Deploy command = npx wrangler deploy (needs wrangler.jsonc + public/ in the repo).
If your Render address is not https://aacselect.onrender.com, edit public/config.js.
GITHUB: upload everything in this folder to the TOP LEVEL of the repo (server.js, package.json, wrangler.jsonc, render.yaml, public/).
