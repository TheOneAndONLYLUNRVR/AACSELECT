// Where the live server (Render) is. Same-origin when the page itself is served by the server.
if(window.AAC_API===undefined){var h=location.hostname;window.AAC_API=(h==='localhost'||h==='127.0.0.1'||/onrender\.com$/.test(h))?'':'https://aacselect.onrender.com'}
