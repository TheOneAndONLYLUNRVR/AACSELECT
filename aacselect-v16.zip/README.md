# AACSELECT v14 (unofficial fan project) - exact settings
RENDER (runs the server):  Root Directory = EMPTY | Build Command = npm install | Start Command = node server.js  (NEVER npx wrangler deploy)
  Health Check Path = /healthz | Env: DB_FILE=/data/data.json, NODE_VERSION=22 | Disk mounted at /data | Auto-Deploy = On Commit
  Test: open https://YOUR-SERVICE.onrender.com/healthz  ->  {"ok":1,...}
CLOUDFLARE (shows the page):  Pages -> Upload assets -> upload aacselect-cloudflare-site.zip (no build). Add custom domain aacselect.com.
  Git build alternative: Root = / | Build command = EMPTY | Deploy command = npx wrangler deploy (needs wrangler.jsonc + public/ in the repo).
If your Render address is not https://aacselect.onrender.com, edit public/config.js.
GITHUB: upload everything in this folder to the TOP LEVEL of the repo (server.js, package.json, wrangler.jsonc, render.yaml, public/).

## v15 - SPOTLIGHT (visitor MP4 promos)
Visitors upload an MP4 (max 30 MB, <=60 s) + title + creator name + @handle; the gallery updates live for everyone; cards have NOD/NOMINATE, share, report.
Videos are saved next to your data file (on Render: /data/promos) -> needs the Disk. They auto-expire after 14 days; max 40 videos / 400 MB.
Safety: real-MP4 check, size cap, 2 uploads/day per person + 4/day per network, swear filter, 3 reports hide a video.
Optional env vars: ADMIN_KEY (lets YOU delete a video), MAX_PROMO_MB (default 30), PROMO_CAP_MB (default 400).
Delete a video (owner): curl -X POST https://YOUR-SITE/api/promo/delete -H "Content-Type: application/json" -d '{"id":"VIDEO_ID","key":"YOUR_ADMIN_KEY"}'

## v16 - Axiom Guard v2
The old filter blocked any name that merely CONTAINED a bad word ("Entity_B" has "tit", "grape" has "rape"). v2 matches whole words and also catches disguises (f.u.c.k, sh1t, f u c k, xXfuckXx).
Mild words (damn, crap, piss, homo, tit, cock...) are no longer blocked. Edit the word lists in server.js (GD_WORD / GD_STRONG) and the same block inside public/assets/index-*.js (search "AXIOM GUARD v2").
