# AACSELECT v17 (unofficial fan project) — https://aacselect.onrender.com/

## Deploy (Render)
Upload everything in this folder to the TOP LEVEL of your GitHub repo (server.js, package.json, render.yaml, wrangler.jsonc, public/). Render redeploys on commit.
Render settings: Root Directory = EMPTY | Build Command = `npm install` | Start Command = `node server.js` | Health Check Path = `/healthz`.

## Environment variables (Render → your service → Environment)
| Key | What it does |
|---|---|
| `ADMIN_KEY` | Optional. The admin panel password is built in (stored only as a scrambled hash in server.js). Set this to use a different password instead. |
| `S3_ENDPOINT`, `S3_BUCKET`, `S3_KEY_ID`, `S3_SECRET`, `S3_REGION` | **Cloud bucket — this is what stops the site from being wiped.** See below. |
| `MAX_PROMO_MB` (250), `MAX_IMAGE_MB` (25) | Spotlight upload limits. |
| `PROMO_CAP_MB` | Total Spotlight storage (default 8000 MB with a bucket, 900 MB without). |
| `KEEPALIVE=0` | Turns the stay-awake ping off (it is ON by default). |

## Why everything got wiped — and the fix
Render's free plan has **no permanent disk**: every restart, redeploy or wake-up starts from an empty folder, so nominations, votes, chat and videos vanished.
v17 saves everything (Board, votes, chat, champions, bans **and** Spotlight files) to a free S3-compatible cloud bucket and restores it on every start. It also writes a dated backup copy once per day (`backups/state-YYYY-MM-DD.json`).

**Option A — Cloudflare R2 (10 GB free, you already use Cloudflare):**
1. Cloudflare dashboard → R2 Object Storage → Create bucket → name it `aacselect`.
2. R2 → Manage API tokens → Create API token → permission **Object Read & Write**, limited to the `aacselect` bucket.
3. Copy into Render: `S3_ENDPOINT` = `https://<ACCOUNT_ID>.r2.cloudflarestorage.com` (shown on the token page), `S3_BUCKET` = `aacselect`, `S3_KEY_ID` = Access Key ID, `S3_SECRET` = Secret Access Key, `S3_REGION` = `auto`.

**Option B — Backblaze B2 (10 GB free, no card needed):** create a **private** bucket, then App Keys → Add a New Application Key for that bucket.
`S3_ENDPOINT` = `https://s3.<region>.backblazeb2.com` (the "Endpoint" shown on the bucket, e.g. `s3.us-west-004.backblazeb2.com`), `S3_REGION` = the region part (e.g. `us-west-004`), `S3_KEY_ID` = keyID, `S3_SECRET` = applicationKey.

**Check it works:** open https://aacselect.onrender.com/healthz → it must say `"cloud":"on"`. The admin panel also shows a green "CLOUD SAVE ON" chip.
(Alternative without a bucket: a paid Render plan + a Disk mounted at `/data` and `DB_FILE=/data/data.json`.)

## Always on ("eternal" server)
The free plan sleeps after 15 minutes without visitors. The server now pings its own public address about every 10 minutes so it never falls asleep. For extra safety add a free monitor at uptimerobot.com (HTTP, every 5 min) on `https://aacselect.onrender.com/healthz`.
Free plan = 750 hours/month, enough for one service running 24/7. Render can still restart the server for deploys/maintenance; with the bucket set up nothing is lost.
While the server restarts, visitors now see the last known Board (marked RECONNECTING) instead of an empty one.

## v17 changes
1. **Spotlight:** videos up to **250 MB / 3 minutes** (MP4, MOV, WebM) and **images** (JPG, PNG, WebP, GIF up to 25 MB). Tap a video to turn its sound on.
2. **Nominations stay** for the whole cycle and are only cleared after the countdown ends **and a winner is announced** (if nobody voted, the Board carries over to the next cycle).
3. **Nominating someone already on the Board = a nod** from you (matched by handle/link or by name, so `@Nova`, `tiktok.com/@nova` and "Nova" all count for the same creator). One nod per person per cycle.
4. Address everywhere is now **aacselect.onrender.com**.
5. Stay-awake ping + cloud saving (above).
6. **Hidden admin panel — AXIOM CONTROL.**

## AXIOM CONTROL (developer only)
**Open it:** scroll to the very bottom of the site and **double-click (or double-tap on a phone) the AAC badge in the footer**. It asks for the developer password; the correct password opens the Admin Panel. Wrong passwords are refused, and 6 wrong tries lock that network out for 10 minutes. The password is case-sensitive. To change it, set `ADMIN_KEY` on Render.
- **LIVE NOW:** everyone on the site right now: name (if they chatted), short visitor ID, device/browser, network tag, time connected, tabs, actions. **KICK** (disconnects them, they can rejoin after 15 s) or **BAN**.
- **Ban bar:** ban anyone, even if they're not on the site — type a **visitor ID**, a **chat name**, or an **IP address**. A name nobody has used yet becomes a waiting ban: whoever chats with that name is banned instantly.
- **How long:** 10 min, 1 hour, 1 day, 7 days, 30 days, forever, or any exact number of minutes/hours/days, plus a reason (shown to them). "Also block their network" stops them coming back in a new browser/private window (note: it also blocks others on that same Wi-Fi).
- Banned visitors get a full-screen animated **BANNED** screen with the reason and a live countdown; it lifts by itself when the time is up, or instantly when you press **UNBAN** in the **BANS** tab.
- **RECENT VISITORS** (last 45 days) and **BOARD · SPOTLIGHT · CHAT** (remove a creator, delete a Spotlight post, clear chat).

## Earlier notes
- Axiom Guard v2 word lists: `GD_WORD` / `GD_STRONG` in server.js and the "AXIOM GUARD v2" block in `public/assets/index-v17.js`.
- `CYCLE_MIN=2` makes a whole cycle last 2 minutes (testing only).
